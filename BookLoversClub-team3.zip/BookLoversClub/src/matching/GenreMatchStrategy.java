package matching;

import model.User;

import java.util.HashSet;
import java.util.Set;

/** Similarity by favorite genres (Jaccard index). */
public class GenreMatchStrategy implements MatchStrategy {
    public double score(User a, User b) {
        return jaccard(a.getFavoriteGenres(), b.getFavoriteGenres());
    }
    public String name() { return "By genres"; }

    static <T> double jaccard(Set<T> x, Set<T> y) {
        if (x.isEmpty() && y.isEmpty()) return 0;
        Set<T> intersection = new HashSet<>(x);
        intersection.retainAll(y);
        Set<T> union = new HashSet<>(x);
        union.addAll(y);
        return (double) intersection.size() / union.size();
    }
}
