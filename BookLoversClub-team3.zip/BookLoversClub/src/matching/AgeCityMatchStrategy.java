package matching;

import model.User;

/** Closeness in age and living in the same city. */
public class AgeCityMatchStrategy implements MatchStrategy {
    public double score(User a, User b) {
        double ageScore = Math.max(0, 1 - Math.abs(a.getAge() - b.getAge()) / 8.0);
        double cityScore = a.getCity().equalsIgnoreCase(b.getCity()) ? 1.0 : 0.0;
        return 0.5 * ageScore + 0.5 * cityScore;
    }
    public String name() { return "By age and city"; }
}
