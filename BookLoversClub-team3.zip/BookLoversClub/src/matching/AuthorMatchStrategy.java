package matching;

import model.User;

import java.util.HashSet;
import java.util.Set;

/** Similarity by favorite authors and authors of books already read. */
public class AuthorMatchStrategy implements MatchStrategy {
    public double score(User a, User b) {
        Set<String> authorsA = new HashSet<>(a.getFavoriteAuthors());
        Set<String> authorsB = new HashSet<>(b.getFavoriteAuthors());
        a.getReadBooks().forEach(book -> authorsA.add(book.getAuthor()));
        b.getReadBooks().forEach(book -> authorsB.add(book.getAuthor()));
        return GenreMatchStrategy.jaccard(authorsA, authorsB);
    }
    public String name() { return "By authors"; }
}
