package matching;

import model.User;

import java.util.LinkedHashMap;
import java.util.Map;

/** Combined strategy with weights. */
public class WeightedMatchStrategy implements MatchStrategy {
    private final Map<MatchStrategy, Double> weights = new LinkedHashMap<>();

    public WeightedMatchStrategy add(MatchStrategy s, double weight) {
        weights.put(s, weight);
        return this;
    }

    public double score(User a, User b) {
        double total = weights.values().stream().mapToDouble(Double::doubleValue).sum();
        if (total == 0) return 0;
        double sum = 0;
        for (Map.Entry<MatchStrategy, Double> e : weights.entrySet()) {
            sum += e.getKey().score(a, b) * e.getValue();
        }
        return sum / total;
    }
    public String name() { return "Weighted (combined)"; }
}
