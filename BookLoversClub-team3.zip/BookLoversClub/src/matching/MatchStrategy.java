package matching;

import model.User;

/** STRATEGY (existing): interchangeable matchmaking algorithms. */
public interface MatchStrategy {
    /** Compatibility from 0.0 to 1.0 */
    double score(User a, User b);
    String name();
}
