package repository;

import model.User;

import java.util.*;

/** SINGLETON (existing): one shared, thread-safe user storage. */
public class UserRepository {
    private static volatile UserRepository instance;
    private final Map<String, User> users = new LinkedHashMap<>();

    private UserRepository() { }

    /** Thread-safe lazy initialization (double-checked locking). */
    public static UserRepository getInstance() {
        if (instance == null) {
            synchronized (UserRepository.class) {
                if (instance == null) {
                    instance = new UserRepository();
                }
            }
        }
        return instance;
    }

    public void save(User user)               { users.put(user.getId(), user); }
    public Optional<User> findById(String id) { return Optional.ofNullable(users.get(id)); }
    public Collection<User> findAll()         { return Collections.unmodifiableCollection(users.values()); }
    public int count()                        { return users.size(); }
}
