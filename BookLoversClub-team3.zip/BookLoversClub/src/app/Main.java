package app;

import analytics.AgeStatisticsVisitor;
import analytics.ClubStatistics;
import facade.BookLoversClub;
import matching.*;
import model.*;
import report.CsvReport;
import report.MarkdownReport;
import report.TextReport;
import repository.UserRepository;

import java.time.LocalDate;
import java.util.*;

/*
 * =====================================================================
 *   Young Book Lovers Dating Club - Design Patterns Demo (Team 3)
 *   Direction: "Book Catalog and Analytics"
 * =====================================================================
 *  Existing patterns:
 *   1. Singleton               - repository.UserRepository
 *   2. Builder                 - model.User.Builder
 *   3. Factory Method          - notification.NotifierFactory
 *   4. Strategy                - matching.MatchStrategy
 *   5. Observer                - notification.ClubEventBus
 *   6. Decorator               - profile.ProfileView
 *   7. Adapter                 - catalog.LegacyCatalogAdapter
 *   8. Chain of Responsibility - validation.RegistrationValidator
 *   9. Facade                  - facade.BookLoversClub
 *  New patterns (Team 3):
 *  10. Flyweight               - catalog.BookFlyweightFactory (+ model.ReadingRecord)
 *  11. Visitor                 - analytics.ClubVisitor and its 3 visitors
 *  12. Template Method         - report.ClubReport (Text / Csv / Markdown)
 * =====================================================================
 */
public class Main {
    public static void main(String[] args) {
        BookLoversClub club = new BookLoversClub();

        System.out.println("===== 1. Registration (Builder + Chain of Responsibility + Singleton) =====");
        User aigerim = new User.Builder("Aigerim", 20)
                .city("Almaty")
                .contact(ContactChannel.TELEGRAM, "@aigerim_reads")
                .genres(Genre.FANTASY, Genre.CLASSIC, Genre.POETRY)
                .authors("Mikhail Bulgakov", "J.K. Rowling")
                .about("I love reading in coffee shops")
                .build();

        User arman = new User.Builder("Arman", 22)
                .city("Almaty")
                .contact(ContactChannel.EMAIL, "arman@mail.kz")
                .genres(Genre.FANTASY, Genre.SCI_FI, Genre.CLASSIC)
                .authors("Frank Herbert", "Mikhail Bulgakov")
                .build();

        User dana = new User.Builder("Dana", 19)
                .city("Astana")
                .contact(ContactChannel.SMS, "+7 701 000 00 00")
                .genres(Genre.DETECTIVE, Genre.ROMANCE)
                .authors("Agatha Christie")
                .build();

        User timur = new User.Builder("Timur", 24)
                .city("Almaty")
                .contact(ContactChannel.TELEGRAM, "@timur_books")
                .genres(Genre.NON_FICTION, Genre.SCI_FI, Genre.CLASSIC)
                .authors("Yuval Noah Harari", "Erich Maria Remarque")
                .build();

        User tooOld = new User.Builder("Victor", 45)
                .contact(ContactChannel.EMAIL, "victor@mail.kz")
                .genres(Genre.CLASSIC)
                .build();

        User noGenres = new User.Builder("Olzhas", 18)
                .contact(ContactChannel.EMAIL, "olzhas@mail.kz")
                .build();

        club.register(aigerim);
        club.register(arman);
        club.register(dana);
        club.register(timur);
        club.register(tooOld);
        club.register(noGenres);
        System.out.println("Total members: " + club.membersCount()
                + " (Singleton: same repository instance? "
                + (UserRepository.getInstance() == UserRepository.getInstance()) + ")");

        System.out.println("\n===== 2. Books read (Adapter + Flyweight) =====");
        club.addReadBook(aigerim, "978-5-17-080115-2", 5, LocalDate.of(2026, 1, 15));
        club.addReadBook(aigerim, "978-5-389-07435-4", 4, LocalDate.of(2026, 2, 3));
        club.addReadBook(aigerim, "978-5-389-01006-2", 5, LocalDate.of(2026, 3, 9));
        club.addReadBook(arman, "978-5-17-090630-7", 5, LocalDate.of(2026, 1, 28));
        club.addReadBook(arman, "978-5-17-080115-2", 4, LocalDate.of(2026, 2, 20));
        club.addReadBook(dana, "978-5-699-12014-7", 4, LocalDate.of(2026, 2, 11));
        club.addReadBook(timur, "978-5-04-116500-3", 5, LocalDate.of(2026, 3, 1));
        club.addReadBook(timur, "978-5-17-118366-0", 3, LocalDate.of(2026, 3, 22));
        club.addReadBook(timur, "000-0-00-000000-0", 3, LocalDate.of(2026, 3, 30));

        System.out.println("\n===== 3. Profiles (Decorator) =====");
        club.verify(aigerim);
        System.out.println(club.showProfile(aigerim));
        System.out.println(club.showProfile(timur));

        System.out.println("\n===== 4. Finding matches for Aigerim (Strategy) =====");
        List<MatchStrategy> strategies = Arrays.asList(
                new GenreMatchStrategy(),
                new AuthorMatchStrategy(),
                new AgeCityMatchStrategy(),
                new WeightedMatchStrategy()
                        .add(new GenreMatchStrategy(), 0.4)
                        .add(new AuthorMatchStrategy(), 0.4)
                        .add(new AgeCityMatchStrategy(), 0.2)
        );
        for (MatchStrategy s : strategies) {
            System.out.println("Strategy: " + s.name());
            List<Match> matches = club.findMatches(aigerim, s, 3);
            if (matches.isEmpty()) System.out.println("   no matches");
            matches.forEach(m -> System.out.println("   " + m));
        }

        System.out.println("\n===== 5. Introduction (Observer + Factory Method) =====");
        MatchStrategy best = strategies.get(strategies.size() - 1);
        List<Match> top = club.findMatches(aigerim, best, 1);
        if (!top.isEmpty()) {
            club.introduce(aigerim, top.get(0).user, best);
        }

        System.out.println("\n===== 6. Book club meetup (Observer) =====");
        club.announceMeetup("The Master and Margarita", "Bookworm Cafe, Almaty", "October 12, 6:00 PM");

        // ================= TEAM 3: new patterns =================

        System.out.println("\n===== 7. Flyweight: shared Book objects =====");
        // A fifth member and more reading, so that books are shared between users.
        User madina = new User.Builder("Madina", 21)
                .city("Almaty")
                .contact(ContactChannel.TELEGRAM, "@madina_pages")
                .genres(Genre.CLASSIC, Genre.FANTASY, Genre.ROMANCE)
                .authors("Antoine de Saint-Exupery")
                .build();
        club.register(madina);

        club.addReadBook(madina, "978-5-17-080115-2", 5, LocalDate.of(2026, 4, 2));
        club.addReadBook(madina, "978-5-389-01006-2", 5, LocalDate.of(2026, 4, 18));
        club.addReadBook(madina, "978-5-389-07435-4", 4, LocalDate.of(2026, 5, 5));
        club.addReadBook(dana, "978-5-17-080115-2", 5, LocalDate.of(2026, 4, 10));
        club.addReadBook(dana, "978-5-389-01006-2", 4, LocalDate.of(2026, 4, 25));
        club.addReadBook(arman, "978-5-17-118366-0", 4, LocalDate.of(2026, 5, 14));

        List<User> members = Arrays.asList(aigerim, arman, dana, timur, madina);

        Book viaLookup1 = club.findBook("978-5-17-080115-2").get();
        Book viaLookup2 = club.findBook("978-5-17-080115-2").get();
        Book aigerimsBook = aigerim.getReadingRecords().get(0).getBook();
        Book armansBook = arman.getReadingRecords().stream()
                .filter(r -> r.getBook().getIsbn().equals("978-5-17-080115-2"))
                .findFirst().get().getBook();
        System.out.println("Two direct lookups of the same ISBN  : lookup1 == lookup2 -> " + (viaLookup1 == viaLookup2));
        System.out.println("Aigerim's copy vs Arman's copy       : aigerimsBook == armansBook -> " + (aigerimsBook == armansBook));

        Map<Book, Integer> identityReaders = new IdentityHashMap<>();
        int totalReads = 0;
        for (User u : members) {
            for (ReadingRecord r : u.getReadingRecords()) {
                identityReaders.merge(r.getBook(), 1, Integer::sum);
                totalReads++;
            }
        }
        System.out.println("Reading records (user + rating + date): " + totalReads);
        System.out.println("Distinct Book instances in memory     : " + identityReaders.size());
        System.out.println("Book objects created by the factory   : " + club.bookObjectsCreated()
                + " (from " + club.bookLookups() + " requests)");
        identityReaders.entrySet().stream()
                .sorted((x, y) -> y.getValue() - x.getValue())
                .forEach(e -> System.out.println("   1 instance, " + e.getValue() + " reader(s): " + e.getKey().getTitle()));
        System.out.println("Extrinsic state example (Madina's journal):");
        madina.getReadingRecords().forEach(r -> System.out.println("   " + r));

        System.out.println("\n===== 8. Visitor: club statistics =====");
        ClubStatistics stats = club.collectStatistics();
        System.out.println("GenrePopularityVisitor:");
        stats.genres().ranking().forEach(e -> System.out.println("   " + e.getKey() + " - " + e.getValue() + " reads"));
        System.out.println("   Most popular genre: " + stats.genres().mostPopular().get());
        AgeStatisticsVisitor ages = stats.ages();
        System.out.println(String.format(Locale.US,
                "AgeStatisticsVisitor:\n   members=%d, average=%.1f, min=%d, max=%d",
                ages.count(), ages.average(), ages.min(), ages.max()));
        System.out.println("TopAuthorsVisitor (top 3):");
        stats.authors().top3().forEach(e -> System.out.println("   " + e.getKey() + " - " + e.getValue() + " reads"));

        System.out.println("\n===== 9. Template Method: the same report in three formats =====");
        System.out.println("--- TextReport (console) ---");
        System.out.println(club.generateReport(TextReport::new));
        System.out.println("--- CsvReport ---");
        System.out.println(club.generateReport(CsvReport::new));
        System.out.println("--- MarkdownReport ---");
        System.out.println(club.generateReport(MarkdownReport::new));
    }
}
