package profile;

public abstract class ProfileDecorator implements ProfileView {
    protected final ProfileView inner;
    protected ProfileDecorator(ProfileView inner) { this.inner = inner; }
}
