package profile;

/** DECORATOR (existing): component interface. */
public interface ProfileView {
    String render();
}
