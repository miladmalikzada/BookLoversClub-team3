package profile;

import model.User;

public class ReadingStatsDecorator extends ProfileDecorator {
    private final User user;
    public ReadingStatsDecorator(ProfileView inner, User user) { super(inner); this.user = user; }

    public String render() {
        int count = user.getReadBooks().size();
        String level = count >= 5 ? "Bookworm 🐛" : count >= 2 ? "Reader 📖" : "Newbie 🌱";
        return inner.render() + "\n   📚 Books read: " + count + " — " + level;
    }
}
