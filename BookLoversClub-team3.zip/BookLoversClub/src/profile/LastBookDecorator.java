package profile;

import model.Book;
import model.User;

import java.util.List;

public class LastBookDecorator extends ProfileDecorator {
    private final User user;
    public LastBookDecorator(ProfileView inner, User user) { super(inner); this.user = user; }

    public String render() {
        List<Book> books = user.getReadBooks();
        if (books.isEmpty()) return inner.render();
        return inner.render() + "\n   🔖 Last book: " + books.get(books.size() - 1);
    }
}
