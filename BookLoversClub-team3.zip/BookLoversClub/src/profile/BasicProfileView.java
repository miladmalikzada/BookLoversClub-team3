package profile;

import model.User;

public class BasicProfileView implements ProfileView {
    private final User user;
    public BasicProfileView(User user) { this.user = user; }

    public String render() {
        return "👤 " + user.getName() + ", " + user.getAge() + " y.o., " + user.getCity()
                + "\n   Genres: " + user.getFavoriteGenres()
                + "\n   Authors: " + user.getFavoriteAuthors()
                + (user.getAbout().isEmpty() ? "" : "\n   About: " + user.getAbout());
    }
}
