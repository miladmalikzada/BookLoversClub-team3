package profile;

public class VerifiedBadgeDecorator extends ProfileDecorator {
    public VerifiedBadgeDecorator(ProfileView inner) { super(inner); }
    public String render() { return inner.render() + "\n   ✅ Verified profile"; }
}
