package model;

import analytics.ClubVisitor;

/**
 * A book. Immutable, so it can be safely shared between many users.
 *
 * FLYWEIGHT (Team 3): this class holds only the INTRINSIC state (isbn, title, author, genre).
 * The per-user data (rating, date read) lives in {@link ReadingRecord}.
 * Instances must be obtained through {@code catalog.BookFlyweightFactory}, never with {@code new}.
 *
 * VISITOR (Team 3): {@link #accept(ClubVisitor)} is the "door" through which visitors enter,
 * so statistics can be added without touching this class again.
 */
public final class Book {
    private final String isbn;
    private final String title;
    private final String author;
    private final Genre genre;

    public Book(String isbn, String title, String author, Genre genre) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.genre = genre;
    }

    public String getIsbn()   { return isbn; }
    public String getTitle()  { return title; }
    public String getAuthor() { return author; }
    public Genre getGenre()   { return genre; }

    /** Visitor: double dispatch. */
    public void accept(ClubVisitor visitor) { visitor.visitBook(this); }

    @Override
    public String toString() { return "\"" + title + "\" by " + author + " (" + genre + ")"; }
}
