package model;

import java.time.LocalDate;

/**
 * FLYWEIGHT (Team 3) - the EXTRINSIC state.
 * Everything that is specific to one user reading one book (rating, date) is stored here,
 * while the shared {@link Book} is just referenced.
 */
public final class ReadingRecord {
    private final Book book;
    private final int rating;          // 1..5, 0 = not rated
    private final LocalDate dateRead;

    public ReadingRecord(Book book, int rating, LocalDate dateRead) {
        if (rating < 0 || rating > 5) throw new IllegalArgumentException("Rating must be 0..5");
        this.book = book;
        this.rating = rating;
        this.dateRead = dateRead;
    }

    public Book getBook()          { return book; }
    public int getRating()         { return rating; }
    public LocalDate getDateRead() { return dateRead; }

    @Override
    public String toString() {
        return book.getTitle() + " - " + (rating == 0 ? "not rated" : rating + "/5") + ", read on " + dateRead;
    }
}
