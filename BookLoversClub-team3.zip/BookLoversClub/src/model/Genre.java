package model;

public enum Genre { FANTASY, SCI_FI, DETECTIVE, CLASSIC, ROMANCE, NON_FICTION, POETRY }
