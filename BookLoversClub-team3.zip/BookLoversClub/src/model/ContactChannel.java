package model;

public enum ContactChannel { EMAIL, TELEGRAM, SMS }
