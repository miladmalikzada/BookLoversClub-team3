package model;

import analytics.ClubVisitor;

import java.util.*;
import java.util.stream.Collectors;

/**
 * BUILDER (existing): {@link Builder} creates a profile step by step.
 * VISITOR (Team 3): {@link #accept(ClubVisitor)}.
 */
public class User {
    private final String id;
    private final String name;
    private final int age;
    private final String city;
    private final String contact;
    private final ContactChannel channel;
    private final String about;
    private final Set<Genre> favoriteGenres;
    private final Set<String> favoriteAuthors;
    private final List<ReadingRecord> readings;
    private boolean verified;

    private User(Builder b) {
        this.id = UUID.randomUUID().toString().substring(0, 8);
        this.name = b.name;
        this.age = b.age;
        this.city = b.city;
        this.contact = b.contact;
        this.channel = b.channel;
        this.about = b.about;
        this.favoriteGenres = b.favoriteGenres;
        this.favoriteAuthors = b.favoriteAuthors;
        this.readings = new ArrayList<>();
    }

    public String getId()                   { return id; }
    public String getName()                 { return name; }
    public int getAge()                     { return age; }
    public String getCity()                 { return city; }
    public String getContact()              { return contact; }
    public ContactChannel getChannel()      { return channel; }
    public String getAbout()                { return about; }
    public Set<Genre> getFavoriteGenres()   { return favoriteGenres; }
    public Set<String> getFavoriteAuthors() { return favoriteAuthors; }
    public boolean isVerified()             { return verified; }
    public void setVerified(boolean v)      { this.verified = v; }

    /** Per-user reading data (extrinsic state): rating + date + a reference to the shared Book. */
    public List<ReadingRecord> getReadingRecords() { return Collections.unmodifiableList(readings); }

    /** Convenience view kept for the existing code (matching strategies, profile decorators). */
    public List<Book> getReadBooks() {
        return readings.stream().map(ReadingRecord::getBook).collect(Collectors.toList());
    }

    public void addReading(ReadingRecord record) { readings.add(record); }

    /**
     * Visitor: the user is visited first, then every book they have read (one visit per read),
     * so a visitor can count "how many reads" without any change to the model.
     */
    public void accept(ClubVisitor visitor) {
        visitor.visitUser(this);
        for (ReadingRecord r : readings) {
            r.getBook().accept(visitor);
        }
    }

    @Override
    public String toString() { return name + " (" + age + ", " + city + ")"; }

    public static class Builder {
        private final String name;
        private final int age;
        private String city = "Not specified";
        private String contact = "";
        private ContactChannel channel = ContactChannel.EMAIL;
        private String about = "";
        private final Set<Genre> favoriteGenres = new HashSet<>();
        private final Set<String> favoriteAuthors = new HashSet<>();

        public Builder(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public Builder city(String city)                    { this.city = city; return this; }
        public Builder contact(ContactChannel ch, String c) { this.channel = ch; this.contact = c; return this; }
        public Builder about(String about)                  { this.about = about; return this; }
        public Builder genres(Genre... genres)              { favoriteGenres.addAll(Arrays.asList(genres)); return this; }
        public Builder authors(String... authors)           { favoriteAuthors.addAll(Arrays.asList(authors)); return this; }

        public User build() { return new User(this); }
    }
}
