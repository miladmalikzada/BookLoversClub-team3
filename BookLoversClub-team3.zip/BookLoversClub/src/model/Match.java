package model;

import java.util.Locale;

public class Match {
    public final User user;
    public final double score;

    public Match(User user, double score) {
        this.user = user;
        this.score = score;
    }

    @Override
    public String toString() {
        return String.format(Locale.US, "%s — %.0f%% compatible", user, score * 100);
    }
}
