package report;

import analytics.AgeStatisticsVisitor;
import analytics.ClubStatistics;
import model.Genre;

import java.util.Locale;
import java.util.Map;

/** CSV report: one "section,key,value" row per fact. */
public class CsvReport extends ClubReport {
    public CsvReport(ClubStatistics stats) { super(stats); }

    @Override
    protected String header() { return "section,key,value\n"; }

    @Override
    protected String body() {
        StringBuilder sb = new StringBuilder();
        AgeStatisticsVisitor a = stats.ages();
        sb.append("members,count,").append(a.count()).append('\n');
        sb.append(String.format(Locale.US, "age,average,%.1f\n", a.average()));
        sb.append("age,min,").append(a.min()).append('\n');
        sb.append("age,max,").append(a.max()).append('\n');
        for (Map.Entry<Genre, Integer> e : stats.genres().ranking()) {
            sb.append("genre,").append(e.getKey()).append(',').append(e.getValue()).append('\n');
        }
        for (Map.Entry<String, Integer> e : stats.authors().top3()) {
            sb.append("author,").append(escape(e.getKey())).append(',').append(e.getValue()).append('\n');
        }
        return sb.toString();
    }

    @Override
    protected String footer() { return "report,generated_by,BookLoversClub\n"; }

    private static String escape(String s) {
        return (s.contains(",") || s.contains("\"")) ? "\"" + s.replace("\"", "\"\"") + "\"" : s;
    }
}
