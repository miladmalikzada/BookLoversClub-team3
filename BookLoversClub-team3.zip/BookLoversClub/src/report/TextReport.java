package report;

import analytics.AgeStatisticsVisitor;
import analytics.ClubStatistics;
import model.Genre;

import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Plain-text report for the console. */
public class TextReport extends ClubReport {
    public TextReport(ClubStatistics stats) { super(stats); }

    @Override
    protected String header() {
        return "==============================================\n"
             + "  " + title() + "\n"
             + "==============================================\n";
    }

    @Override
    protected String body() {
        StringBuilder sb = new StringBuilder();
        AgeStatisticsVisitor a = stats.ages();
        sb.append("Members: ").append(a.count()).append('\n');
        sb.append(String.format(Locale.US, "Age: average %.1f, min %d, max %d\n", a.average(), a.min(), a.max()));
        sb.append("\nMost popular genres (reads):\n");
        int i = 1;
        for (Map.Entry<Genre, Integer> e : stats.genres().ranking()) {
            sb.append("  ").append(i++).append(". ").append(e.getKey()).append(" - ").append(e.getValue()).append('\n');
        }
        sb.append("\nTop 3 authors (reads):\n");
        i = 1;
        List<Map.Entry<String, Integer>> top = stats.authors().top3();
        for (Map.Entry<String, Integer> e : top) {
            sb.append("  ").append(i++).append(". ").append(e.getKey()).append(" - ").append(e.getValue()).append('\n');
        }
        return sb.toString();
    }

    @Override
    protected String footer() {
        return "----------------- end of report ---------------\n";
    }
}
