package report;

import analytics.ClubStatistics;

/**
 * TEMPLATE METHOD (Team 3).
 *
 * {@link #generate()} is the template: it is final and fixes the ORDER of the algorithm
 * (header -> body -> footer). Subclasses only fill in the steps, so a new format
 * (HTML, JSON ...) is a new subclass and no existing class is modified.
 * The data always comes from the visitors via {@link ClubStatistics}.
 *
 * Template Method vs Strategy: Template Method varies steps of ONE algorithm through
 * inheritance (compile time); Strategy swaps the WHOLE algorithm through composition (runtime).
 */
public abstract class ClubReport {
    protected final ClubStatistics stats;

    protected ClubReport(ClubStatistics stats) { this.stats = stats; }

    /** The template method. Final - subclasses cannot change the order of steps. */
    public final String generate() {
        return header() + body() + footer();
    }

    /** Hook with a default implementation; subclasses may override. */
    protected String title() { return "Book Lovers Club - statistics"; }

    protected abstract String header();
    protected abstract String body();
    protected abstract String footer();
}
