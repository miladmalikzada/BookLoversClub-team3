package analytics;

import model.Book;
import model.User;

/**
 * VISITOR (Team 3): the operation interface.
 *
 * Why it is needed here: administrators want statistics, but adding "countGenres()",
 * "averageAge()" ... to User and Book would bloat the model with reporting code.
 * Each new statistic is a new visitor class; User and Book only need accept().
 *
 * Note: User.accept() calls visitUser() once and then visitBook() once per book read,
 * so visitBook() is called once per "read" (a book read by 3 users is visited 3 times).
 */
public interface ClubVisitor {
    void visitUser(User u);
    void visitBook(Book b);
}
