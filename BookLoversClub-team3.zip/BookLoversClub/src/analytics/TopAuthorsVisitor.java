package analytics;

import model.Book;
import model.User;

import java.util.*;
import java.util.stream.Collectors;

/** Top authors by number of reads (default: top 3). */
public class TopAuthorsVisitor implements ClubVisitor {
    private final Map<String, Integer> reads = new HashMap<>();

    @Override public void visitUser(User u) { /* authors come from books */ }

    @Override public void visitBook(Book b) { reads.merge(b.getAuthor(), 1, Integer::sum); }

    public List<Map.Entry<String, Integer>> top(int n) {
        List<Map.Entry<String, Integer>> list = new ArrayList<>(reads.entrySet());
        list.sort((a, b) -> {
            int c = Integer.compare(b.getValue(), a.getValue());
            return c != 0 ? c : a.getKey().compareTo(b.getKey());
        });
        return list.stream().limit(n).collect(Collectors.toList());
    }

    public List<Map.Entry<String, Integer>> top3() { return top(3); }
}
