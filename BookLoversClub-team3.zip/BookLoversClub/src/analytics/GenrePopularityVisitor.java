package analytics;

import model.Book;
import model.Genre;
import model.User;

import java.util.*;

/** Counts reads per genre -> "most popular genres". */
public class GenrePopularityVisitor implements ClubVisitor {
    private final Map<Genre, Integer> reads = new EnumMap<>(Genre.class);

    @Override public void visitUser(User u) { /* genres come from books */ }

    @Override public void visitBook(Book b) { reads.merge(b.getGenre(), 1, Integer::sum); }

    /** Genres sorted by number of reads (descending), ties by name. */
    public List<Map.Entry<Genre, Integer>> ranking() {
        List<Map.Entry<Genre, Integer>> list = new ArrayList<>(reads.entrySet());
        list.sort((a, b) -> {
            int c = Integer.compare(b.getValue(), a.getValue());
            return c != 0 ? c : a.getKey().name().compareTo(b.getKey().name());
        });
        return list;
    }

    public Optional<Genre> mostPopular() {
        List<Map.Entry<Genre, Integer>> r = ranking();
        return r.isEmpty() ? Optional.empty() : Optional.of(r.get(0).getKey());
    }
}
