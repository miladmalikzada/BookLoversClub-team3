package analytics;

import model.User;

import java.util.Collection;

/**
 * Bundles the three visitors after they have walked over the club.
 * It is the single data source for every report (see the report package).
 */
public final class ClubStatistics {
    private final GenrePopularityVisitor genres = new GenrePopularityVisitor();
    private final AgeStatisticsVisitor ages = new AgeStatisticsVisitor();
    private final TopAuthorsVisitor authors = new TopAuthorsVisitor();

    private ClubStatistics() { }

    /** Sends all three visitors through every user (and, through the users, every read book). */
    public static ClubStatistics collect(Collection<User> users) {
        ClubStatistics stats = new ClubStatistics();
        for (User u : users) {
            u.accept(stats.genres);
            u.accept(stats.ages);
            u.accept(stats.authors);
        }
        return stats;
    }

    public GenrePopularityVisitor genres() { return genres; }
    public AgeStatisticsVisitor ages()     { return ages; }
    public TopAuthorsVisitor authors()     { return authors; }
}
