package analytics;

import model.Book;
import model.User;

/** Average, minimum and maximum age of the members. */
public class AgeStatisticsVisitor implements ClubVisitor {
    private int count;
    private long sum;
    private int min = Integer.MAX_VALUE;
    private int max = Integer.MIN_VALUE;

    @Override
    public void visitUser(User u) {
        count++;
        sum += u.getAge();
        min = Math.min(min, u.getAge());
        max = Math.max(max, u.getAge());
    }

    @Override public void visitBook(Book b) { /* not interested in books */ }

    public int count()      { return count; }
    public double average() { return count == 0 ? 0 : (double) sum / count; }
    public int min()        { return count == 0 ? 0 : min; }
    public int max()        { return count == 0 ? 0 : max; }
}
