package validation;

import model.User;

/** CHAIN OF RESPONSIBILITY (existing): sequential, extendable registration checks. */
public abstract class RegistrationValidator {
    private RegistrationValidator next;

    public RegistrationValidator linkWith(RegistrationValidator next) {
        this.next = next;
        return next;
    }

    /** Returns null if the user is valid, otherwise an error message. */
    public String validate(User user) {
        String error = check(user);
        if (error != null) return error;
        return next == null ? null : next.validate(user);
    }

    protected abstract String check(User user);
}
