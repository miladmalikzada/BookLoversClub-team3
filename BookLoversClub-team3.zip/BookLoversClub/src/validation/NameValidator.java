package validation;

import model.User;

public class NameValidator extends RegistrationValidator {
    @Override
    protected String check(User u) {
        return (u.getName() == null || u.getName().trim().length() < 2)
                ? "Name must be at least 2 characters long" : null;
    }
}
