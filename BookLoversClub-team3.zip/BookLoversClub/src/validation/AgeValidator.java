package validation;

import model.User;

public class AgeValidator extends RegistrationValidator {
    public static final int MIN_AGE = 14;
    public static final int MAX_AGE = 30;

    @Override
    protected String check(User u) {
        return (u.getAge() < MIN_AGE || u.getAge() > MAX_AGE)
                ? "The club is for young people aged " + MIN_AGE + " to " + MAX_AGE : null;
    }
}
