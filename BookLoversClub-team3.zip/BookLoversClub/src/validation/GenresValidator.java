package validation;

import model.User;

public class GenresValidator extends RegistrationValidator {
    @Override
    protected String check(User u) {
        return u.getFavoriteGenres().isEmpty()
                ? "Please choose at least one favorite genre" : null;
    }
}
