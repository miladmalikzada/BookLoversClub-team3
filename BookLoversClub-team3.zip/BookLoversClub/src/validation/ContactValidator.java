package validation;

import model.ContactChannel;
import model.User;

public class ContactValidator extends RegistrationValidator {
    @Override
    protected String check(User u) {
        String c = u.getContact();
        if (c == null || c.isEmpty()) return "Please provide a contact for notifications";
        if (u.getChannel() == ContactChannel.EMAIL && !c.contains("@"))
            return "Invalid e-mail address";
        return null;
    }
}
