package catalog;

import model.Book;
import model.Genre;

import java.util.HashMap;
import java.util.Map;

/**
 * FLYWEIGHT FACTORY (Team 3).
 *
 * Why it is needed here: before this class, LegacyCatalogAdapter did "new Book(...)" on every lookup,
 * so "The Master and Margarita" read by 100 users meant 100 identical objects in memory.
 * The factory keeps a pool keyed by ISBN and always returns the same shared Book.
 *
 * Intrinsic state (shared, immutable): isbn, title, author, genre  -> {@link Book}
 * Extrinsic state (per user):          rating, date read           -> {@link model.ReadingRecord}
 *
 * Difference from Singleton: Singleton guarantees ONE instance of ONE class;
 * Flyweight guarantees one instance per distinct key (here: per ISBN) and there are many of them.
 */
public class BookFlyweightFactory {
    private final Map<String, Book> pool = new HashMap<>();
    private int requests;

    /** Returns the shared Book for this ISBN, creating it only on the first request. */
    public synchronized Book getBook(String isbn, String title, String author, Genre genre) {
        requests++;
        return pool.computeIfAbsent(isbn, k -> new Book(isbn, title, author, genre));
    }

    /** How many distinct Book objects were really created. */
    public synchronized int createdCount() { return pool.size(); }

    /** How many times a Book was requested (including requests served from the cache). */
    public synchronized int requestsCount() { return requests; }
}
