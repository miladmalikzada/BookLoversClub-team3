package catalog;

import java.util.HashMap;
import java.util.Map;

/** Old city library catalog with an inconvenient API (cannot be modified) - the Adaptee. */
public class LegacyLibraryCatalog {
    private final Map<String, String> records = new HashMap<>();

    public LegacyLibraryCatalog() {
        records.put("978-5-17-080115-2", "The Master and Margarita|Mikhail Bulgakov|CLS");
        records.put("978-5-389-07435-4", "Harry Potter and the Philosopher's Stone|J.K. Rowling|FNT");
        records.put("978-5-17-090630-7", "Dune|Frank Herbert|SCF");
        records.put("978-5-699-12014-7", "Murder on the Orient Express|Agatha Christie|DET");
        records.put("978-5-17-118366-0", "Three Comrades|Erich Maria Remarque|CLS");
        records.put("978-5-389-01006-2", "The Little Prince|Antoine de Saint-Exupery|CLS");
        records.put("978-5-04-116500-3", "Sapiens|Yuval Noah Harari|NFC");
    }

    /** Returns a string in the format "title|author|CODE", or null. */
    public String lookupRecord(String code) { return records.get(code); }
}
