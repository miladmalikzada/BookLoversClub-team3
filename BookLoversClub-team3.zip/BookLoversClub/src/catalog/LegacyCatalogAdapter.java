package catalog;

import model.Book;
import model.Genre;

import java.util.Optional;

/**
 * ADAPTER (existing): converts the legacy "title|author|CODE" strings into {@link Book} objects.
 * Now it does not create books itself but asks the {@link BookFlyweightFactory} (FLYWEIGHT, Team 3).
 */
public class LegacyCatalogAdapter implements BookCatalog {
    private final LegacyLibraryCatalog legacy;
    private final BookFlyweightFactory flyweights;

    public LegacyCatalogAdapter(LegacyLibraryCatalog legacy, BookFlyweightFactory flyweights) {
        this.legacy = legacy;
        this.flyweights = flyweights;
    }

    @Override
    public Optional<Book> findByIsbn(String isbn) {
        String raw = legacy.lookupRecord(isbn);
        if (raw == null) return Optional.empty();
        String[] parts = raw.split("\\|");
        return Optional.of(flyweights.getBook(isbn, parts[0], parts[1], convertGenre(parts[2])));
    }

    private Genre convertGenre(String code) {
        switch (code) {
            case "FNT": return Genre.FANTASY;
            case "SCF": return Genre.SCI_FI;
            case "DET": return Genre.DETECTIVE;
            case "ROM": return Genre.ROMANCE;
            case "NFC": return Genre.NON_FICTION;
            case "POE": return Genre.POETRY;
            case "CLS":
            default:    return Genre.CLASSIC;
        }
    }
}
