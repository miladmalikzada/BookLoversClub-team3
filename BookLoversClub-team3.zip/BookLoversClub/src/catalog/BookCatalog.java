package catalog;

import model.Book;

import java.util.Optional;

/** The interface our system expects (target of the Adapter). */
public interface BookCatalog {
    Optional<Book> findByIsbn(String isbn);
}
