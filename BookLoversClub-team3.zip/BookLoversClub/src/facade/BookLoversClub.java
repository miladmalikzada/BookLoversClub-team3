package facade;

import analytics.ClubStatistics;
import catalog.BookCatalog;
import catalog.BookFlyweightFactory;
import catalog.LegacyCatalogAdapter;
import catalog.LegacyLibraryCatalog;
import matching.MatchStrategy;
import model.Book;
import model.Genre;
import model.Match;
import model.ReadingRecord;
import model.User;
import notification.ClubEventBus;
import notification.UserSubscriber;
import profile.*;
import report.ClubReport;
import repository.UserRepository;
import validation.*;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * FACADE (existing): the single entry point for the whole system.
 * Team 3 additions (all reachable only through this class):
 *   findBook / addReadBook(rating, date) / bookObjectsCreated  -> Flyweight
 *   collectStatistics                                           -> Visitor
 *   generateReport                                              -> Template Method (+ Visitor data)
 */
public class BookLoversClub {
    public static final String EVENT_NEW_MATCH = "NEW_MATCH";
    public static final String EVENT_MEETUP    = "CLUB_MEETUP";

    private final UserRepository repository = UserRepository.getInstance();
    private final ClubEventBus eventBus = new ClubEventBus();
    private final BookFlyweightFactory bookFactory = new BookFlyweightFactory();
    private final BookCatalog catalog = new LegacyCatalogAdapter(new LegacyLibraryCatalog(), bookFactory);
    private final RegistrationValidator validator;
    private final Map<String, UserSubscriber> subscribers = new HashMap<>();

    public BookLoversClub() {
        validator = new NameValidator();
        validator.linkWith(new AgeValidator())
                 .linkWith(new GenresValidator())
                 .linkWith(new ContactValidator());
    }

    /** Registration: validation + saving + subscribing to events. */
    public boolean register(User user) {
        String error = validator.validate(user);
        if (error != null) {
            System.out.println("❌ Registration of " + user.getName() + " rejected: " + error);
            return false;
        }
        repository.save(user);
        UserSubscriber sub = new UserSubscriber(user);
        subscribers.put(user.getId(), sub);
        eventBus.subscribe(EVENT_MEETUP, sub);
        System.out.println("✔ Registered: " + user);
        return true;
    }

    public void verify(User user) { user.setVerified(true); }

    // ------------------------- catalog (Adapter + Flyweight) -------------------------

    /** Looks a book up by ISBN. The same ISBN always returns the very same Book object. */
    public Optional<Book> findBook(String isbn) { return catalog.findByIsbn(isbn); }

    /** Adds a book the user has read (not rated, read today). */
    public void addReadBook(User user, String isbn) {
        addReadBook(user, isbn, 0, LocalDate.now());
    }

    /** Adds a book the user has read: shared Book (intrinsic) + ReadingRecord (extrinsic). */
    public void addReadBook(User user, String isbn, int rating, LocalDate dateRead) {
        Optional<Book> book = catalog.findByIsbn(isbn);
        if (book.isPresent()) {
            user.addReading(new ReadingRecord(book.get(), rating, dateRead));
            System.out.println("   " + user.getName() + " has read " + book.get()
                    + (rating > 0 ? " [" + rating + "/5]" : ""));
        } else {
            System.out.println("   Book with ISBN " + isbn + " was not found in the catalog");
        }
    }

    /** How many Book objects really exist (Flyweight pool size). */
    public int bookObjectsCreated() { return bookFactory.createdCount(); }

    /** How many times a Book was requested from the pool. */
    public int bookLookups() { return bookFactory.requestsCount(); }

    // ------------------------- analytics (Visitor) -------------------------

    /** Walks all three visitors over the whole club. */
    public ClubStatistics collectStatistics() { return ClubStatistics.collect(repository.findAll()); }

    // ------------------------- reports (Template Method) -------------------------

    /**
     * Builds a report in the requested format, e.g. {@code club.generateReport(CsvReport::new)}.
     * A new format is just a new ClubReport subclass - this method does not change.
     */
    public String generateReport(Function<ClubStatistics, ClubReport> format) {
        return format.apply(collectStatistics()).generate();
    }

    // ------------------------- matching / events / profiles -------------------------

    /** Finds the best matches using the chosen strategy. */
    public List<Match> findMatches(User user, MatchStrategy strategy, int limit) {
        return repository.findAll().stream()
                .filter(other -> !other.getId().equals(user.getId()))
                .map(other -> new Match(other, strategy.score(user, other)))
                .filter(m -> m.score > 0)
                .sorted((m1, m2) -> Double.compare(m2.score, m1.score))
                .limit(limit)
                .collect(Collectors.toList());
    }

    /** Introduction: both users get a notification. */
    public void introduce(User a, User b, MatchStrategy strategy) {
        double score = strategy.score(a, b);
        String pct = String.format(Locale.US, "%.0f%%", score * 100);
        Set<Genre> common = commonGenres(a, b);
        subscribers.get(a.getId()).onEvent(EVENT_NEW_MATCH,
                "Meet " + b.getName() + " (" + pct + " match). Shared genres: " + common);
        subscribers.get(b.getId()).onEvent(EVENT_NEW_MATCH,
                "Meet " + a.getName() + " (" + pct + " match). Shared genres: " + common);
    }

    /** Book club meetup - broadcast to all subscribers. */
    public void announceMeetup(String bookTitle, String place, String date) {
        eventBus.publish(EVENT_MEETUP, "Discussing \"" + bookTitle + "\" — " + place + ", " + date);
    }

    /** Renders a profile wrapped in decorators. */
    public String showProfile(User user) {
        ProfileView view = new BasicProfileView(user);
        view = new ReadingStatsDecorator(view, user);
        view = new LastBookDecorator(view, user);
        if (user.isVerified()) view = new VerifiedBadgeDecorator(view);
        return view.render();
    }

    public int membersCount() { return repository.count(); }

    private Set<Genre> commonGenres(User a, User b) {
        Set<Genre> s = new HashSet<>(a.getFavoriteGenres());
        s.retainAll(b.getFavoriteGenres());
        return s;
    }
}
