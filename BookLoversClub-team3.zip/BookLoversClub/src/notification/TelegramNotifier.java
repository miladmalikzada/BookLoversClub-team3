package notification;

import model.User;

public class TelegramNotifier implements Notifier {
    public void send(User to, String message) {
        System.out.println("   [Telegram -> " + to.getContact() + "] " + message);
    }
}
