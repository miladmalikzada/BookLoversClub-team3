package notification;

import model.ContactChannel;

/** FACTORY METHOD (existing): creates the right notifier for the user's contact channel. */
public class NotifierFactory {
    public static Notifier create(ContactChannel channel) {
        switch (channel) {
            case TELEGRAM: return new TelegramNotifier();
            case SMS:      return new SmsNotifier();
            case EMAIL:
            default:       return new EmailNotifier();
        }
    }
}
