package notification;

import model.User;

public interface Notifier {
    void send(User to, String message);
}
