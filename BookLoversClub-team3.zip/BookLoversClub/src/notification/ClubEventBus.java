package notification;

import java.util.*;

/** OBSERVER (existing): publishes club events to subscribers. */
public class ClubEventBus {
    private final Map<String, List<ClubEventListener>> listeners = new HashMap<>();

    public void subscribe(String eventType, ClubEventListener l) {
        listeners.computeIfAbsent(eventType, k -> new ArrayList<>()).add(l);
    }

    public void unsubscribe(String eventType, ClubEventListener l) {
        List<ClubEventListener> list = listeners.get(eventType);
        if (list != null) list.remove(l);
    }

    public void publish(String eventType, String message) {
        for (ClubEventListener l : listeners.getOrDefault(eventType, Collections.emptyList())) {
            l.onEvent(eventType, message);
        }
    }
}
