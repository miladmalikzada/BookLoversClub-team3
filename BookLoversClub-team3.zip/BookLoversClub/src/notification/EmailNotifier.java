package notification;

import model.User;

public class EmailNotifier implements Notifier {
    public void send(User to, String message) {
        System.out.println("   [E-mail -> " + to.getContact() + "] " + message);
    }
}
