package notification;

import model.User;

public class SmsNotifier implements Notifier {
    public void send(User to, String message) {
        System.out.println("   [SMS -> " + to.getContact() + "] " + message);
    }
}
