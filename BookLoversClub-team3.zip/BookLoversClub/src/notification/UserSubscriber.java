package notification;

import model.User;

/** OBSERVER (existing): a user-subscriber receives events through their own contact channel. */
public class UserSubscriber implements ClubEventListener {
    private final User user;
    private final Notifier notifier;

    public UserSubscriber(User user) {
        this.user = user;
        this.notifier = NotifierFactory.create(user.getChannel()); // Factory used inside Observer
    }

    @Override
    public void onEvent(String eventType, String message) {
        notifier.send(user, "[" + eventType + "] " + message);
    }
}
