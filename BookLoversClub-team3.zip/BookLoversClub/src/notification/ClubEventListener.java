package notification;

public interface ClubEventListener {
    void onEvent(String eventType, String message);
}
